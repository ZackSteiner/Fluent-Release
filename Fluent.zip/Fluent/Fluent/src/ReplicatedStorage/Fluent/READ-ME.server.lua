--[[
══════════════════════════════════════════════════════════════════════

███████╗██╗     ██╗   ██╗███████╗███╗   ██╗████████╗
██╔════╝██║     ██║   ██║██╔════╝████╗  ██║╚══██╔══╝
█████╗  ██║     ██║   ██║█████╗  ██╔██╗ ██║   ██║   
██╔══╝  ██║     ██║   ██║██╔══╝  ██║╚██╗██║   ██║   
██║     ███████╗╚██████╔╝███████╗██║ ╚████║   ██║   
╚═╝     ╚══════╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝
══════════════════════════════════════════════════════════════════════
Hey, thanks for installing Fluent into your project!

























══════════════════════════════════════════════════════════════════════
--]]

-- BELOW THIS LINE IT WILL PRINT THE VERSION NUMBER IN A LIVE GAME HOWEVER IN STUDIO IT WILL PRINT THE HEADER AND SOME OTHER INFO.

local RunService = game:GetService("RunService") local MarketplaceService = game:GetService("MarketplaceService") local placeInfo = MarketplaceService:GetProductInfo(game.PlaceId) local Main = require(game:GetService("ReplicatedStorage"):WaitForChild("Fluent"):WaitForChild("MainModule"))
if game.TestService == true or RunService:IsStudio() then

	warn([[ 
══════════════════════════════════════════════════════════════════════

███████╗██╗     ██╗   ██╗███████╗███╗   ██╗████████╗
██╔════╝██║     ██║   ██║██╔════╝████╗  ██║╚══██╔══╝
█████╗  ██║     ██║   ██║█████╗  ██╔██╗ ██║   ██║   
██╔══╝  ██║     ██║   ██║██╔══╝  ██║╚██╗██║   ██║   
██║     ███████╗╚██████╔╝███████╗██║ ╚████║   ██║   
╚═╝     ╚══════╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝
                    Fluent Version: ]] .. Main.Version .. [[

══════════════════════════════════════════════════════════════════════
👋 Hi Developer, this note will only show in Studio.
]])
else
	print(placeInfo.Name .. "is using Fluent Version: " .. Main.Version) 
end
