return {
	Name = "Ocean Wave",
	Accent = Color3.fromRGB(0, 162, 255),

	AcrylicMain = Color3.fromRGB(10, 20, 30),
	AcrylicBorder = Color3.fromRGB(30, 50, 80),
	AcrylicGradient = ColorSequence.new(Color3.fromRGB(0, 100, 200), Color3.fromRGB(0, 60, 120)),
	AcrylicNoise = 0.9,

	TitleBarLine = Color3.fromRGB(0, 80, 150),
	Tab = Color3.fromRGB(80, 140, 240),

	Element = Color3.fromRGB(50, 100, 180),
	ElementBorder = Color3.fromRGB(20, 40, 70),
	InElementBorder = Color3.fromRGB(60, 80, 120),
	ElementTransparency = 0.85,

	ToggleSlider = Color3.fromRGB(50, 100, 180),
	ToggleToggled = Color3.fromRGB(255, 255, 255),

	SliderRail = Color3.fromRGB(50, 100, 180),

	DropdownFrame = Color3.fromRGB(100, 160, 220),
	DropdownHolder = Color3.fromRGB(20, 30, 50),
	DropdownBorder = Color3.fromRGB(0, 40, 80),
	DropdownOption = Color3.fromRGB(50, 100, 180),

	Keybind = Color3.fromRGB(50, 100, 180),

	Input = Color3.fromRGB(50, 100, 180),
	InputFocused = Color3.fromRGB(0, 20, 40),
	InputIndicator = Color3.fromRGB(100, 180, 240),

	Dialog = Color3.fromRGB(20, 30, 50),
	DialogHolder = Color3.fromRGB(10, 20, 40),
	DialogHolderLine = Color3.fromRGB(0, 20, 40),
	DialogButton = Color3.fromRGB(20, 30, 50),
	DialogButtonBorder = Color3.fromRGB(40, 60, 80),
	DialogBorder = Color3.fromRGB(30, 50, 70),
	DialogInput = Color3.fromRGB(20, 30, 50),
	DialogInputLine = Color3.fromRGB(150, 210, 240),

	Text = Color3.fromRGB(240, 240, 240),
	SubText = Color3.fromRGB(180, 180, 180),
	Hover = Color3.fromRGB(50, 100, 180),
	HoverChange = 0.05
}
