return {
	Name = "Forest Breeze",
	Accent = Color3.fromRGB(34, 139, 34),

	AcrylicMain = Color3.fromRGB(20, 20, 20),
	AcrylicBorder = Color3.fromRGB(70, 100, 70),
	AcrylicGradient = ColorSequence.new(Color3.fromRGB(85, 160, 85), Color3.fromRGB(34, 68, 34)),
	AcrylicNoise = 0.9,

	TitleBarLine = Color3.fromRGB(50, 100, 50),
	Tab = Color3.fromRGB(100, 160, 100),

	Element = Color3.fromRGB(60, 120, 60),
	ElementBorder = Color3.fromRGB(30, 70, 30),
	InElementBorder = Color3.fromRGB(40, 90, 40),
	ElementTransparency = 0.86,

	ToggleSlider = Color3.fromRGB(60, 120, 60),
	ToggleToggled = Color3.fromRGB(0, 0, 0),

	SliderRail = Color3.fromRGB(60, 120, 60),

	DropdownFrame = Color3.fromRGB(100, 160, 100),
	DropdownHolder = Color3.fromRGB(30, 50, 30),
	DropdownBorder = Color3.fromRGB(20, 40, 20),
	DropdownOption = Color3.fromRGB(60, 120, 60),

	Keybind = Color3.fromRGB(60, 120, 60),

	Input = Color3.fromRGB(60, 120, 60),
	InputFocused = Color3.fromRGB(10, 20, 10),
	InputIndicator = Color3.fromRGB(100, 160, 100),

	Dialog = Color3.fromRGB(30, 50, 30),
	DialogHolder = Color3.fromRGB(20, 40, 20),
	DialogHolderLine = Color3.fromRGB(15, 30, 15),
	DialogButton = Color3.fromRGB(30, 50, 30),
	DialogButtonBorder = Color3.fromRGB(50, 80, 50),
	DialogBorder = Color3.fromRGB(40, 70, 40),
	DialogInput = Color3.fromRGB(30, 50, 30),
	DialogInputLine = Color3.fromRGB(150, 255, 150),

	Text = Color3.fromRGB(240, 240, 240),
	SubText = Color3.fromRGB(170, 170, 170),
	Hover = Color3.fromRGB(60, 120, 60),
	HoverChange = 0.05
}
