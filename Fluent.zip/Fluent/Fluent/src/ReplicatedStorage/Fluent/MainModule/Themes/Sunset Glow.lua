return {
	Name = "Sunset Glow",
	Accent = Color3.fromRGB(255, 100, 0),

	AcrylicMain = Color3.fromRGB(20, 20, 20),
	AcrylicBorder = Color3.fromRGB(100, 50, 30),
	AcrylicGradient = ColorSequence.new(Color3.fromRGB(255, 150, 50), Color3.fromRGB(100, 20, 20)),
	AcrylicNoise = 0.88,

	TitleBarLine = Color3.fromRGB(200, 80, 20),
	Tab = Color3.fromRGB(255, 180, 70),

	Element = Color3.fromRGB(230, 100, 20),
	ElementBorder = Color3.fromRGB(150, 70, 20),
	InElementBorder = Color3.fromRGB(200, 130, 30),
	ElementTransparency = 0.85,

	ToggleSlider = Color3.fromRGB(230, 100, 20),
	ToggleToggled = Color3.fromRGB(0, 0, 0),

	SliderRail = Color3.fromRGB(230, 100, 20),

	DropdownFrame = Color3.fromRGB(255, 200, 90),
	DropdownHolder = Color3.fromRGB(100, 40, 20),
	DropdownBorder = Color3.fromRGB(70, 30, 15),
	DropdownOption = Color3.fromRGB(230, 100, 20),

	Keybind = Color3.fromRGB(230, 100, 20),

	Input = Color3.fromRGB(230, 100, 20),
	InputFocused = Color3.fromRGB(40, 10, 10),
	InputIndicator = Color3.fromRGB(255, 200, 90),

	Dialog = Color3.fromRGB(100, 40, 20),
	DialogHolder = Color3.fromRGB(80, 30, 15),
	DialogHolderLine = Color3.fromRGB(60, 20, 10),
	DialogButton = Color3.fromRGB(100, 40, 20),
	DialogButtonBorder = Color3.fromRGB(150, 70, 20),
	DialogBorder = Color3.fromRGB(120, 50, 30),
	DialogInput = Color3.fromRGB(90, 30, 15),
	DialogInputLine = Color3.fromRGB(255, 200, 90),

	Text = Color3.fromRGB(240, 240, 240),
	SubText = Color3.fromRGB(170, 170, 170),
	Hover = Color3.fromRGB(230, 100, 20),
	HoverChange = 0.05
}
